# Kamino Moon
 Adds the planet Kamino from Star Wars to Lethal Company

![Kamino](https://raw.githubusercontent.com/Puremask/Kamino-Moon/main/screenshots/20240112131613_1.jpg "Kamino")

# Report a bug :
I will maybe open a Discord for support if the mod gets a lot of users, meanwhile you can use the [github's issue tab](https://github.com/Puremask/Kamino-Moon/issues).

## Known issues :
- Water around map abruptly ends (trying to figure out LODs for the horizon).
- Rain sometimes just stops when exiting the interior. Genuinely not sure why.

##Screenshots:
![Kamino](https://raw.githubusercontent.com/Puremask/Kamino-Moon/main/screenshots/20240112131648_1.jpg "Kamino")
![Kamino](https://raw.githubusercontent.com/Puremask/Kamino-Moon/main/screenshots/20240112131745_1.jpg "Kamino")
![Kamino](https://raw.githubusercontent.com/Puremask/Kamino-Moon/main/screenshots/20240112143441_1.jpg "Kamino")